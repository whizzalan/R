library(testthat)
library(slidify)

test_package('slidify')