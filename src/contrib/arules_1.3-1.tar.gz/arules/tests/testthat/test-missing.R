## FIXME: missing tests
## * itemCoding
## * aggregate
## * discretize
## * dissimilarity
## * pmml
## * predict
## * supportingTransactions

